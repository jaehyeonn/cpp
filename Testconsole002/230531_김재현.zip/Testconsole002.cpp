﻿// Testconsole002.cpp : 이 파일에는 'main' 함수가 포함됩니다. 거기서 프로그램 실행이 시작되고 종료됩니다.
//

#include <iostream>
// 이런게 함수의 정의다
//void kjh(int age)
//{
//	printf("이름:김재현\n");
//	printf("전화번호 : 01079794136\n");
//	// 
//		printf("나이:%d",age );
//
//}
//void attack(float critical)
//{
//	printf("데미지 %f", critical * 3.5);
//	
//}
//int plus(int num1, int num2)
//{
//	printf("%d + %d = %d\n", num1, num2, num1 + num2);
//	return 0;
//}
//
//int Minus(int num1, int num2)
//{
//	printf("%d - %d = %d\n", num1, num2, num1 - num2);
//	return 0;
//}
//int multi(int num1, int num2)
//{
//	printf("%d * %d = %d\n", num1, num2, num1 * num2);
//	return 0;
//}
//int divide(float num1, float num2)
//{
//	printf("%f / %f = %f\n", num1, num2, num1 / num2);
//	return 0;
//}
//int mod(int num1, int num2)
//{
//	printf("%d %% %d = %d\n", num1, num2, num1 % num2);
//		return 0;
//}

//int heal(int heal)
//{
//	int maxHp = 50;
//	int curentHp = 20;
//	printf("힐을 받은후 체력 %d \n", ((heal + curentHp) < maxHp) ? (heal + curentHp) : maxHp);
//
//	return 0;
//}






int main()
{
	int zzang = 0, com = 2;
	printf("가위1, 바위2, 보3, 골라주세요\n");
	scanf_s("%d", &zzang);
	(zzang == 3) ? printf("\n승리\n\n") : ((zzang == 2) ? printf("\n무승부\n\n") : printf("\n패배\n\n"));

	return 0;

	/*printf("숫자 값을 입력해주세요 >");
	int input = 0;
	scanf_s("%d", &input);
	printf("input 의 값은 %d \n", input);*/

}
	
	
	







	//heal (10);
	//heal(50);
	//

	
	//int num1 = 9, int num2 = 2;
	//printf("%d + %d = %d \n", num1, num2, num1 + num2 );
	//printf("%d + %d = %d \n", num1, num2, num1 - num2 );
	//printf("%d + %d = %d \n", num1, num2, num1 * num2);
	//printf("%d + %d = %d \n", num1, num2, num1 / num2);
	//printf("%d + %d = %d \n", num1, num2, num1  num2);


	///*int number = -10;
	//printf("number 변수를 찍어볼까 ? : %d \n\n", number);*/

	//int num1 = 9, int num2 = 2;
	//	int result1 = 0;
	//	//result1 = result1 + (num1 + num2);
	//	result1 += (num1 + num2);

	//	printf("%d + %d = %d \n", num1, num2, result1);

		//int somenumber = 0;
		//somenumber = somenumber++;
		//printf("somenumber 안에는 무슨 값이 들어 있을까? %d\n\n\n", somenumber);




		//int num1 = 10;
		//int num2 = 12;
		//int result1, result2, result3;

		//result1 = num1 != num2;
		//result2 = num1 <= num2;
		//result3 = num1 > num2;
		//printf("result1 결과는 %d \n", result1);
		//printf("result2 결과는 %d \n", result2);
		//printf("result3 결과는 %d \n\n\n", result3);


	//int num1 = 10;
	//int num2 = 12;
	//int result1, result2, result3;

	//result1 = (num1 == 10 && num2 == 12);
	//result2 = (num1 < 12 || num2 > 12);
	//result3 = (!num1);


	//printf("result1 %d \n", result1);
	//printf("result2 %d \n", result2);
	//printf("result3 %d \n", result3);

	//int age = 28;
	//bool boolresult;

	//	boolresult = (age < 20) ? true : false;
	//	printf("bool result는 어떤 값?%d\n", boolresult);

	//	














